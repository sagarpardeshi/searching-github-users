var app = angular.module('App', ['ngRoute']);

app.config(function ($routeProvider) {
    $routeProvider
    // home
        .when('/', {
        templateUrl: '../index.html',
        controller: 'mainController'
    })
        .otherwise('/', {
            templateUrl: '../index.html',
            controller: 'mainController'
        });
});

app.controller('mainController', [ '$scope', '$http', 'Pagination',function ($scope, $http, Pagination) {

    var _findurl = "https://api.github.com/search/users?q=";
    var _userurl = "https://api.github.com/users/";

    $scope.users = [];

    /////////////////////////////////////////////////////////////////
    
    $scope.pagination = Pagination.getNew(10);

    ////////////////////////////////////////////////////////////////

    $scope.get_users = function(username) {
        $http.get(_userurl + username).then(function (response) {
                    $scope.users.push(response.data);
            });
    }

    $scope.pagination.numPages = Math.ceil($scope.users.length/$scope.pagination.perPage);

    $scope.find_users = function () {
        $http.get(_findurl + $scope.username+"&page=1&per_page=10").then(function (response) {
                for (i = 0; i < response.data.items.length; i++) {
                    $scope.get_users(response.data.items[i].login);
                }
            });
    };
}]);


//We already have a limitTo filter built-in to angular,
//let's make a startFrom filter
app.filter('startFrom', function() {
    return function(input, start) {
        start = +start; //parse to int
        return input.slice(start);
    }
});

app.directive('ngEnter', function () {
    return function (scope, element, attrs) {
        element.bind("keydown keypress", function (event) {
            if(event.which === 13) {
                scope.$apply(function (){
                    scope.$eval(attrs.ngEnter);
                });
 
                event.preventDefault();
            }
        });
    };
});